#include <stdio.h>

int main(void) {
    int age;
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Age: %d\n", age);
    return 0;
}
